package registrationapp;

import java.util.*;

public class RegistrationApp {

    // ---------- Configuration ----------
    private static final int USERNAME_MAX_LEN = 5;
    private static final int PASSWORD_MIN_LEN = 8;
    private static final int PHONE_MIN_DIGITS = 9;
    private static final int PHONE_MAX_DIGITS = 12;

    // Pre-registered convenience account
    private static final String PRE_USERNAME = "sn_06";
    private static final String PRE_PASSWORD = "Saneli66!";
    private static final String PRE_PHONE = "+27664375596";
    private static final String PRE_FULLNAME = "Sanelisile Nkosi";

    // In-memory stores
    private static final Map<String, String> userDb = new HashMap<>();
    private static final Map<String, String> userFullName = new HashMap<>();
    private static final Map<String, String> userPhone = new HashMap<>();

    // ---------- Validator helpers ----------
    private static class Validator {
        static boolean validateUsername(String username) {
            return username != null && username.contains("_") && username.length() <= USERNAME_MAX_LEN;
        }

        static boolean validatePassword(String password) {
            if (password == null) return false;
            boolean hasUpper = false, hasDigit = false, hasSpecial = false;
            for (char c : password.toCharArray()) {
                if (Character.isUpperCase(c)) hasUpper = true;
                if (Character.isDigit(c)) hasDigit = true;
                if (!Character.isLetterOrDigit(c)) hasSpecial = true;
            }
            return password.length() >= PASSWORD_MIN_LEN && hasUpper && hasDigit && hasSpecial;
        }

        static boolean validateCellNumber(String cell) {
            if (cell == null || !cell.startsWith("+")) return false;
            String digits = cell.substring(1);
            if (!digits.matches("\\d+")) return false;
            return digits.length() >= PHONE_MIN_DIGITS && digits.length() <= PHONE_MAX_DIGITS;
        }
    }

    // ---------- Registration ----------
    private static boolean register(String username, String password, String cell, String fullName) {
        if (userDb.containsKey(username)) return false;
        boolean valid = Validator.validateUsername(username)
                        && Validator.validatePassword(password)
                        && Validator.validateCellNumber(cell);
        if (valid) {
            userDb.put(username, password);
            userFullName.put(username, fullName);
            userPhone.put(username, cell);
        }
        return valid;
    }

    // ---------- Pre-register default account ----------
    private static void preRegisterDefaultUser() {
        userDb.put(PRE_USERNAME, PRE_PASSWORD);
        userFullName.put(PRE_USERNAME, PRE_FULLNAME);
        userPhone.put(PRE_USERNAME, PRE_PHONE);
    }

    // ---------- Automated test runner ----------
    private static void runAutomatedTests() {
        System.out.println("\n=== Automated Test Suite ===\n");

        userDb.clear();
        userFullName.clear();
        userPhone.clear();

        String[][] tests = {
            // {testName, username, password, phone, fullName, expectedResult}
            {"TC1 - All valid", "sa_ne", "Pass@123", "+2781234567", "Test User1", "true"},
            {"TC2 - Username too long", "saneli", "Pass@123", "+2781234567", "Test User2", "false"},
            {"TC3 - Username missing underscore", "sane", "Pass@123", "+2781234567", "Test User3", "false"},
            {"TC4 - Password missing special", "sa_ne", "Pass1234", "+2781234567", "Test User4", "false"},
            {"TC5 - Password too short", "sa_ne", "Pa@1", "+2781234567", "Test User5", "false"},
            {"TC6 - No +country code", "sa_ne", "Pass@123", "0812345678", "Test User6", "false"},
            {"TC7 - Cell too long", "sa_ne", "Pass@123", "+278123456789012", "Test User7", "false"},
            {"TC8 - Multiple errors", "sanelisile", "pass123", "0812345678", "Test User8", "false"}
        };

        int passed = 0;
        for (String[] t : tests) {
            String name = t[0];
            String u = t[1], p = t[2], c = t[3], f = t[4];
            boolean expected = Boolean.parseBoolean(t[5]);
            boolean result = register(u, p, c, f);

            System.out.println(name + " | Expected: " + (expected ? "SUCCESS" : "FAILURE")
                               + " | Actual: " + (result ? "SUCCESS" : "FAILURE")
                               + " | " + (result == expected ? "PASS" : "FAIL"));

            if (result == expected) passed++;
            userDb.clear();
            userFullName.clear();
            userPhone.clear();
        }

        System.out.println("\nTests passed: " + passed + " / " + tests.length);

        // Restore default user
        preRegisterDefaultUser();
    }

    // ---------- main ----------
    public static void main(String[] args) {
        System.out.println("POE Part 1 - Registration & Login (Minimal Test Version)");
        System.out.println("Author: Sanelisile Nkosi");
        preRegisterDefaultUser();
        runAutomatedTests();
    }
}
