import java.util.*;

public class RegistrationApp {

    // ---------- Configuration ----------
    private static final int USERNAME_MAX_LEN = 5; // max 5 characters
    private static final int PASSWORD_MIN_LEN = 8; // min 8 characters
    private static final int PHONE_MIN_DIGITS = 9; // at least 9 digits after +
    private static final int PHONE_MAX_DIGITS = 12; // at most 12 digits after +

    // Pre-registered convenience account (your details)
    private static final String PRE_USERNAME = "sn_06";
    private static final String PRE_PASSWORD = "Saneli66!";
    private static final String PRE_PHONE = "+27664375596";
    private static final String PRE_FULLNAME = "Sanelisile Nkosi";

    // In-memory stores
    private static final Map<String, String> userDb = new LinkedHashMap<>(); // username -> password
    private static final Map<String, String> userFullName = new LinkedHashMap<>(); // username -> full name
    private static final Map<String, String> userPhone = new LinkedHashMap<>(); // username -> phone

    private static final Scanner scanner = new Scanner(System.in);

    // ---------- Validator helpers ----------
    private static class Validator {
        static boolean validateUsername(String username) {
            boolean ok = username != null && username.contains("_") && username.length() <= USERNAME_MAX_LEN;
            if (ok) {
                System.out.println("Username successfully captured.");
            } else {
                System.out.println("Username is not correctly formatted, please ensure that your username contains an underscore and is no more than five characters in length.");
            }
            return ok;
        }

        static boolean validatePassword(String password) {
            if (password == null) {
                System.out.println("Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.");
                return false;
            }

            boolean hasUpper = false;
            boolean hasDigit = false;
            boolean hasSpecial = false;

            for (char c : password.toCharArray()) {
                if (Character.isUpperCase(c)) hasUpper = true;
                if (Character.isDigit(c)) hasDigit = true;
                if (!Character.isLetterOrDigit(c)) hasSpecial = true;
            }

            boolean ok = password.length() >= PASSWORD_MIN_LEN && hasUpper && hasDigit && hasSpecial;
            if (ok) {
                System.out.println("Password successfully captured.");
            } else {
                System.out.println("Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.");
            }
            return ok;
        }

        static boolean validateCellNumber(String cell) {
            if (cell == null || !cell.startsWith("+")) {
                System.out.println("Cell phone number incorrectly formatted or does not include country code (+).");
                return false;
            }
            String digits = cell.substring(1); // remove '+'
            if (!digits.matches("\\d+")) {
                System.out.println("Cell phone number incorrectly formatted or contains invalid characters.");
                return false;
            }
            int len = digits.length();
            boolean ok = (len >= PHONE_MIN_DIGITS && len <= PHONE_MAX_DIGITS);
            if (ok) {
                System.out.println("Cell phone number successfully added.");
            } else {
                System.out.println("Cell phone number incorrectly formatted or does not meet the required length.");
            }
            return ok;
        }
    }

    // ---------- Registration & Login ----------
    private static boolean register(String username, String password, String cell, String fullName) {
        if (userDb.containsKey(username)) {
            System.out.println("Username already exists. Please choose a different username.");
            return false;
        }

        boolean u = Validator.validateUsername(username);
        boolean p = Validator.validatePassword(password);
        boolean c = Validator.validateCellNumber(cell);

        if (u && p && c) {
            userDb.put(username, password);
            userFullName.put(username, fullName);
            userPhone.put(username, cell);
            System.out.println("All inputs are valid. Registration successful.");
            return true;
        } else {
            System.out.println("Registration failed. Please try again.");
            return false;
        }
    }

    private static boolean login(String username, String password) {
        if (userDb.containsKey(username) && userDb.get(username).equals(password)) {
            String fullname = userFullName.getOrDefault(username, username);
            String phone = userPhone.getOrDefault(username, "N/A");
            System.out.println("Login successful. Welcome, " + fullname + "!");
            System.out.println("Registered phone: " + phone);
            return true;
        } else {
            System.out.println("Login failed. Username or password incorrect.");
            return false;
        }
    }

    // ---------- Automated test runner ----------
    private static class TestCase {
        String name;
        String u;
        String p;
        String c;
        String fullName;
        boolean expectRegisterSuccess;

        TestCase(String name, String u, String p, String c, String fullName, boolean expectRegisterSuccess) {
            this.name = name;
            this.u = u;
            this.p = p;
            this.c = c;
            this.fullName = fullName;
            this.expectRegisterSuccess = expectRegisterSuccess;
        }
    }

    private static void runAutomatedTests() {
        System.out.println("\n=== Running Automated Test Suite ===\n");

        // Clear DB for tests then restore pre-registered account after tests
        userDb.clear();
        userFullName.clear();
        userPhone.clear();

        List<TestCase> tests = new ArrayList<>();
        tests.add(new TestCase("TC1 - All valid", "sa_ne", "Pass@123", "+2781234567", "Test User1", true));
        tests.add(new TestCase("TC2 - Username too long", "saneli", "Pass@123", "+2781234567", "Test User2", false));
        tests.add(new TestCase("TC3 - Username missing underscore", "sane", "Pass@123", "+2781234567", "Test User3", false));
        tests.add(new TestCase("TC4 - Password missing special", "sa_ne", "Pass1234", "+2781234567", "Test User4", false));
        tests.add(new TestCase("TC5 - Password too short", "sa_ne", "Pa@1", "+2781234567", "Test User5", false));
        tests.add(new TestCase("TC6 - No +country code", "sa_ne", "Pass@123", "0812345678", "Test User6", false));
        tests.add(new TestCase("TC7 - Cell too long", "sa_ne", "Pass@123", "+278123456789012", "Test User7", false));
        tests.add(new TestCase("TC8 - Multiple errors", "sanelisile", "pass123", "0812345678", "Test User8", false));

        int passed = 0;
        for (TestCase t : tests) {
            System.out.println("-> " + t.name);
            boolean result = register(t.u, t.p, t.c, t.fullName);
            System.out.println("Expected: " + (t.expectRegisterSuccess ? "SUCCESS" : "FAILURE") +
                               " | Actual: " + (result ? "SUCCESS" : "FAILURE"));
            if (result == t.expectRegisterSuccess) {
                System.out.println("Result: PASS\n");
                passed++;
            } else {
                System.out.println("Result: FAIL\n");
            }
            // Clear DB between tests
            userDb.clear();
            userFullName.clear();
            userPhone.clear();
        }

        System.out.println("Automated tests passed: " + passed + " / " + tests.size());
        System.out.println("=== End of Test Suite ===\n");

        // Restore pre-registered convenience account
        preRegisterDefaultUser();
    }

    // ---------- Pre-register default account ----------
    private static void preRegisterDefaultUser() {
        userDb.put(PRE_USERNAME, PRE_PASSWORD);
        userFullName.put(PRE_USERNAME, PRE_FULLNAME);
        userPhone.put(PRE_USERNAME, PRE_PHONE);
    }

    // ---------- Console menu ----------
    private static void interactiveMenu() {
        while (true) {
            System.out.println("\n=== Registration System Menu ===");
            System.out.println("1. Register");
            System.out.println("2. Login");
            System.out.println("3. Run automated tests (POE evidence)");
            System.out.println("4. Exit");
            System.out.print("Choose an option (1-4): ");

            String choice = scanner.nextLine().trim();
            switch (choice) {
                case "1":
                    System.out.print("Enter your username: ");
                    String uname = scanner.nextLine();
                    System.out.print("Enter your password: ");
                    String pwd = scanner.nextLine();
                    System.out.print("Enter your South African / International cell number (include +countrycode): ");
                    String cell = scanner.nextLine();
                    System.out.print("Enter your full name: ");
                    String fullname = scanner.nextLine();
                    register(uname, pwd, cell, fullname);
                    break;

                case "2":
                    System.out.print("Enter username: ");
                    String lu = scanner.nextLine();
                    System.out.print("Enter password: ");
                    String lpw = scanner.nextLine();
                    login(lu, lpw);
                    break;

                case "3":
                    runAutomatedTests();
                    break;

                case "4":
                    System.out.println("Exiting. Good luck with your POE submission!");
                    return;

                default:
                    System.out.println("Invalid choice. Please select 1-4.");
            }
        }
    }

    // ---------- main ----------
    public static void main(String[] args) {
        System.out.println("POE Part 1 - Registration & Login (console)");
        System.out.println("Author: Sanelisile Nkosi");
        System.out.println("Pre-registered account: username = " + PRE_USERNAME + " | password = " + PRE_PASSWORD);
        preRegisterDefaultUser();
        interactiveMenu();
    }
}
