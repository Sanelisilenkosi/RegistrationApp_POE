  import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;

public class RegistrationApp {

    // Configuration
    private static final int USERNAME_MAX_LEN = 5;
    private static final int PASSWORD_MIN_LEN = 8;
    private static final int PHONE_MIN_DIGITS = 9;
    private static final int PHONE_MAX_DIGITS = 12;
    // Pre-registered convenience account

    // In-memory stores
    private static final Map<String, String> userDb = new LinkedHashMap<>();

    // Validator helpers
    private static class Validator {
        static boolean validateUsername(String username) {
            boolean ok = username != null && username.contains("_") && username.length() <= USERNAME_MAX_LEN;
            if (ok) {
                System.out.println("Username successfully captured.");
            } else {
                System.out.println("Username is not correctly formatted, please ensure that your username contains an underscore and is no more than five characters in length.");
            }
            return ok;
        }

        static boolean validatePassword(String password) {
            if (password == null) {
                System.out.println("Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.");
                return false;
            }
            boolean hasUpper = false;
            boolean hasDigit = false;
            boolean hasSpecial = false;
            for (char c : password.toCharArray()) {
                if (Character.isUpperCase(c)) hasUpper = true;
                if (Character.isDigit(c)) hasDigit = true;
                if (!Character.isLetterOrDigit(c)) hasSpecial = true;
            }
            boolean ok = password.length() >= PASSWORD_MIN_LEN && hasUpper && hasDigit && hasSpecial;
            if (ok) {
                System.out.println("Password successfully captured.");
            } else {
                System.out.println("Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.");
            }
            return ok;
        }

        static boolean validateCellNumber(String cell) {
            if (cell == null || !cell.startsWith("+")) {
                System.out.println("Cell phone number incorrectly formatted or does not include country code (+).");
                return false;
            }
            String digits = cell.substring(1);
            if (!digits.matches("\\d+")) {
                System.out.println("Cell phone number incorrectly formatted or contains invalid characters.");
                return false;
            }
            int len = digits.length();
            boolean ok = (len >= PHONE_MIN_DIGITS && len <= PHONE_MAX_DIGITS);
            if (ok) {
                System.out.println("Cell phone number successfully added.");
            } else {
                System.out.println("Cell phone number incorrectly formatted or does not meet the required length.");
            }
            return ok;
        }
    }
//Pre-register default account

